# Cliente Java para Webservice SIAPE

Este projeto contém um cliente Java para consumir o webservice do SIAPE (Sistema Integrado de Administração de Pessoal) disponível em https://www1.siapenet.gov.br/WSSiapenet/services/ConsultaSIAPE?wsdl.

## Requisitos

- Java 11 ou superior
- Maven 3.6 ou superior

## Configuração

1. Clone este repositório
2. Execute o comando Maven para gerar as classes a partir do WSDL:

```bash
mvn clean generate-sources
```

Este comando irá gerar as classes necessárias para consumir o webservice, incluindo a classe `DadosFuncionais`.

## Como usar

O projeto já inclui uma classe principal `SiapeClient` que pode ser usada para consultar os dados funcionais:

```java
// Inicialize o cliente
SiapeClient client = new SiapeClient();

// Consulte os dados funcionais 
// (substitua os parâmetros conforme necessário)
DadosFuncionais dados = client.consultarDadosFuncionais("12345678900");

// Use os dados
System.out.println("Nome: " + dados.getNome());
```

## Personalizando as consultas

O método `consultarDadosFuncionais` e outras chamadas de API podem precisar ser ajustados conforme a documentação oficial do webservice SIAPE. Os métodos fornecidos são exemplos e podem precisar de adaptações para cenários específicos.

## Autenticação

Se o webservice exigir autenticação, você pode configurá-la modificando o método `configurePort()` na classe `SiapeClient` para incluir credenciais:

```java
requestContext.put(BindingProvider.USERNAME_PROPERTY, "seu_usuario");
requestContext.put(BindingProvider.PASSWORD_PROPERTY, "sua_senha");
```

## Observações

- As classes geradas a partir do WSDL estão no pacote `com.siape.client.generated`
- Os logs são configurados usando Logback e são armazenados em `logs/siape-client.log`
- Para visualizar os detalhes das requisições SOAP, verifique os logs de debug

## Troubleshooting

Se você tiver problemas para gerar as classes:

1. Verifique se o WSDL está acessível
2. Tente baixar o WSDL manualmente e usar a versão local:
   
   ```bash
   wget https://www1.siapenet.gov.br/WSSiapenet/services/ConsultaSIAPE?wsdl -O src/main/resources/ConsultaSIAPE.wsdl
   ```

   E ajuste o pom.xml para usar o arquivo local:
   
   ```xml
   <wsdlUrls>
       <wsdlUrl>${project.basedir}/src/main/resources/ConsultaSIAPE.wsdl</wsdlUrl>
   </wsdlUrls>
   ``` 